"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const config = {
    domainName: "threatfarmer.sjrollins.com"
};
exports.default = config;
//# sourceMappingURL=config.js.map